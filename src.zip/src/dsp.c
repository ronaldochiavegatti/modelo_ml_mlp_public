// Lightweight DSP helpers (windowing + radix-2 FFT).
#include "dsp.h"

#include <math.h>
#include <stdlib.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

size_t next_pow2(size_t n) {
    size_t p = 1;
    // Grow by powers of two until p >= n.
    while (p < n) {
        p <<= 1;
    }
    return p;
}

void hamming_window(float *win, size_t n) {
    if (!win || n == 0) {
        return;
    }
    // Classic Hamming coefficients for spectral leakage reduction.
    for (size_t i = 0; i < n; i++) {
        win[i] = 0.54f - 0.46f * cosf((float)(2.0 * M_PI * i) / (float)(n - 1));
    }
}

static void bit_reverse(float *real, float *imag, size_t n) {
    size_t j = 0;
    for (size_t i = 0; i < n; i++) {
        if (i < j) {
            float tmp = real[i];
            real[i] = real[j];
            real[j] = tmp;
            tmp = imag[i];
            imag[i] = imag[j];
            imag[j] = tmp;
        }
        // Flip bits to generate the bit-reversed index sequence.
        size_t bit = n >> 1;
        while (bit > 0 && (j & bit)) {
            j ^= bit;
            bit >>= 1;
        }
        j |= bit;
    }
}

static void fft_inplace(float *real, float *imag, size_t n) {
    // Iterative Cooley-Tukey radix-2 FFT.
    for (size_t len = 2; len <= n; len <<= 1) {
        float ang = (float)(-2.0 * M_PI / (double)len);
        float wlen_real = cosf(ang);
        float wlen_imag = sinf(ang);
        for (size_t i = 0; i < n; i += len) {
            float w_real = 1.0f;
            float w_imag = 0.0f;
            for (size_t j = 0; j < len / 2; j++) {
                size_t u = i + j;
                size_t v = i + j + len / 2;
                float vr = real[v] * w_real - imag[v] * w_imag;
                float vi = real[v] * w_imag + imag[v] * w_real;
                float ur = real[u];
                float ui = imag[u];
                real[u] = ur + vr;
                imag[u] = ui + vi;
                real[v] = ur - vr;
                imag[v] = ui - vi;
                float next_w_real = w_real * wlen_real - w_imag * wlen_imag;
                float next_w_imag = w_real * wlen_imag + w_imag * wlen_real;
                w_real = next_w_real;
                w_imag = next_w_imag;
            }
        }
    }
}

int fft_real(const float *input, size_t n, float *real, float *imag) {
    if (!input || !real || !imag || n == 0) {
        return -1;
    }
    for (size_t i = 0; i < n; i++) {
        real[i] = input[i];
        imag[i] = 0.0f;
    }
    bit_reverse(real, imag, n);
    fft_inplace(real, imag, n);
    return 0;
}

void magnitude_spectrum(const float *real, const float *imag, size_t n, float *mag_out) {
    size_t half = n / 2 + 1;
    for (size_t i = 0; i < half; i++) {
        float re = real[i];
        float im = imag[i];
        mag_out[i] = sqrtf(re * re + im * im);
    }
}
