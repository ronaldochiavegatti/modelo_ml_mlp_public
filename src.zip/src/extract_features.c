// Extract per-file audio features (MFCC + simple spectral stats).
#include "csv.h"
#include "dsp.h"
#include "frame_io.h"
#include "mfcc.h"
#include "util.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

static void print_usage(const char *prog) {
    fprintf(stderr,
            "Usage: %s --input processed --metadata metadata.csv --output features.csv [--n-mfcc 13] [--n-mels 26] [--rolloff 0.85]\n",
            prog);
}

static int header_index(const CsvRow *row, const char *name) {
    for (size_t i = 0; i < row->count; i++) {
        if (strcasecmp(row->fields[i], name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

static float compute_rms(const float *x, size_t len) {
    double sum = 0.0;
    if (!x || len == 0) {
        return 0.0f;
    }
    for (size_t i = 0; i < len; i++) {
        sum += x[i] * x[i];
    }
    return (float)sqrt(sum / (double)len);
}

static float compute_zcr(const float *x, size_t len) {
    size_t count = 0;
    if (!x || len < 2) {
        return 0.0f;
    }
    for (size_t i = 1; i < len; i++) {
        if ((x[i - 1] >= 0.0f && x[i] < 0.0f) || (x[i - 1] < 0.0f && x[i] >= 0.0f)) {
            count++;
        }
    }
    return (float)count / (float)(len - 1);
}

static void compute_spectral_features(const float *mag, size_t n_bins, int sample_rate, int fft_size,
                                      float rolloff_pct, float *centroid, float *rolloff) {
    double mag_sum = 0.0;
    double weighted_sum = 0.0;
    double cumulative = 0.0;
    double target = 0.0;
    float rolloff_freq = 0.0f;

    for (size_t k = 0; k < n_bins; k++) {
        float freq = (float)k * (float)sample_rate / (float)fft_size;
        mag_sum += mag[k];
        weighted_sum += (double)mag[k] * (double)freq;
    }

    if (mag_sum > 0.0) {
        *centroid = (float)(weighted_sum / mag_sum);
    } else {
        *centroid = 0.0f;
    }

    target = mag_sum * (double)rolloff_pct;
    for (size_t k = 0; k < n_bins; k++) {
        cumulative += mag[k];
        if (cumulative >= target) {
            rolloff_freq = (float)k * (float)sample_rate / (float)fft_size;
            break;
        }
    }
    *rolloff = rolloff_freq;
}

int main(int argc, char **argv) {
    const char *input_dir = NULL;
    const char *metadata_path = NULL;
    const char *output_path = NULL;
    int n_mfcc = 13;
    int n_mels = 26;
    float rolloff_pct = 0.85f;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) {
            input_dir = argv[++i];
        } else if (strcmp(argv[i], "--metadata") == 0 && i + 1 < argc) {
            metadata_path = argv[++i];
        } else if (strcmp(argv[i], "--output") == 0 && i + 1 < argc) {
            output_path = argv[++i];
        } else if (strcmp(argv[i], "--n-mfcc") == 0 && i + 1 < argc) {
            n_mfcc = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--n-mels") == 0 && i + 1 < argc) {
            n_mels = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--rolloff") == 0 && i + 1 < argc) {
            rolloff_pct = (float)atof(argv[++i]);
        } else {
            print_usage(argv[0]);
            return 1;
        }
    }

    if (!input_dir || !metadata_path || !output_path) {
        print_usage(argv[0]);
        return 1;
    }

    fprintf(stdout,
            "Extract features: input=%s metadata=%s output=%s n_mfcc=%d n_mels=%d rolloff=%.2f\n",
            input_dir, metadata_path, output_path, n_mfcc, n_mels, rolloff_pct);

    FILE *meta = fopen(metadata_path, "r");
    if (!meta) {
        perror("fopen metadata");
        return 1;
    }

    FILE *out = fopen(output_path, "w");
    if (!out) {
        perror("fopen output");
        fclose(meta);
        return 1;
    }

    char line[8192];
    if (!fgets(line, sizeof(line), meta)) {
        fprintf(stderr, "Empty metadata file\n");
        fclose(meta);
        fclose(out);
        return 1;
    }

    // Map metadata columns to find id and class.
    CsvRow header = {0};
    if (csv_split_line(line, &header) != 0) {
        fprintf(stderr, "Failed to parse metadata header\n");
        fclose(meta);
        fclose(out);
        return 1;
    }

    int id_idx = header_index(&header, "id");
    int class_idx = header_index(&header, "classe");
    csv_free_row(&header);

    if (id_idx < 0 || class_idx < 0) {
        fprintf(stderr, "Missing required columns in metadata: id, classe\n");
        fclose(meta);
        fclose(out);
        return 1;
    }

    // We store mean and std of (MFCCs + RMS + ZCR + centroid + rolloff).
    int feat_dim = n_mfcc + 4;
    fprintf(stdout, "Feature dimension: %d\n", feat_dim);
    fprintf(out, "id,classe");
    for (int i = 0; i < n_mfcc; i++) {
        fprintf(out, ",mfcc%02d_mean", i + 1);
    }
    fprintf(out, ",rms_mean,zcr_mean,centroid_mean,rolloff_mean");
    for (int i = 0; i < n_mfcc; i++) {
        fprintf(out, ",mfcc%02d_std", i + 1);
    }
    fprintf(out, ",rms_std,zcr_std,centroid_std,rolloff_std\n");

    size_t processed = 0;
    size_t missing = 0;
    size_t failed = 0;

    while (fgets(line, sizeof(line), meta)) {
        CsvRow row = {0};
        char frames_path[1024];
        const char *id;
        const char *class_name;

        if (csv_split_line(line, &row) != 0 || row.count == 0) {
            csv_free_row(&row);
            continue;
        }
        if ((size_t)id_idx >= row.count || (size_t)class_idx >= row.count) {
            csv_free_row(&row);
            continue;
        }

        id = row.fields[id_idx];
        class_name = row.fields[class_idx];
        if (!id || !*id || !class_name || !*class_name) {
            csv_free_row(&row);
            continue;
        }

        snprintf(frames_path, sizeof(frames_path), "%s/%s/%s.frames", input_dir, class_name, id);
        if (!file_exists(frames_path)) {
            fprintf(stderr, "Missing frames: %s\n", frames_path);
            missing++;
            csv_free_row(&row);
            continue;
        }

        // Load all frames for this sample (already normalized + framed).
        FrameHeader fh;
        float *frames = NULL;
        if (frames_read_all(frames_path, &fh, &frames) != 0) {
            fprintf(stderr, "Failed to read frames: %s\n", frames_path);
            failed++;
            csv_free_row(&row);
            continue;
        }

        size_t frame_len = fh.frame_len;
        size_t num_frames = fh.num_frames;
        size_t fft_size = next_pow2(frame_len);
        size_t n_bins = fft_size / 2 + 1;

        // FFT buffers sized to the next power of two.
        float *window = (float *)malloc(sizeof(float) * frame_len);
        float *fft_in = (float *)calloc(fft_size, sizeof(float));
        float *real = (float *)malloc(sizeof(float) * fft_size);
        float *imag = (float *)malloc(sizeof(float) * fft_size);
        float *mag = (float *)malloc(sizeof(float) * n_bins);
        float *power = (float *)malloc(sizeof(float) * n_bins);
        float *mfcc = (float *)malloc(sizeof(float) * (size_t)n_mfcc);
        double *sum = (double *)calloc((size_t)feat_dim, sizeof(double));
        double *sumsq = (double *)calloc((size_t)feat_dim, sizeof(double));

        if (!window || !fft_in || !real || !imag || !mag || !power || !mfcc || !sum || !sumsq) {
            fprintf(stderr, "Allocation failed for %s\n", frames_path);
            free(frames);
            free(window);
            free(fft_in);
            free(real);
            free(imag);
            free(mag);
            free(power);
            free(mfcc);
            free(sum);
            free(sumsq);
            failed++;
            csv_free_row(&row);
            continue;
        }

        hamming_window(window, frame_len);

        MfccBank bank;
        if (mfcc_init(&bank, (int)fh.sample_rate, (int)fft_size, n_mels, n_mfcc) != 0) {
            fprintf(stderr, "MFCC init failed for %s\n", frames_path);
            free(frames);
            free(window);
            free(fft_in);
            free(real);
            free(imag);
            free(mag);
            free(power);
            free(mfcc);
            free(sum);
            free(sumsq);
            failed++;
            csv_free_row(&row);
            continue;
        }

        // Aggregate sums and squared sums across frames.
        for (size_t f = 0; f < num_frames; f++) {
            const float *frame = &frames[f * frame_len];

            // RMS: average energy in time domain.
            float rms = compute_rms(frame, frame_len);
            // ZCR: ratio of zero-crossings in the frame.
            float zcr = compute_zcr(frame, frame_len);

            for (size_t i = 0; i < frame_len; i++) {
                fft_in[i] = frame[i] * window[i];
            }
            for (size_t i = frame_len; i < fft_size; i++) {
                fft_in[i] = 0.0f;
            }

            fft_real(fft_in, fft_size, real, imag);
            magnitude_spectrum(real, imag, fft_size, mag);
            for (size_t k = 0; k < n_bins; k++) {
                power[k] = mag[k] * mag[k];
            }

            // Spectral centroid: frequency-weighted average of magnitude.
            // Spectral rolloff: frequency where cumulative energy reaches rolloff_pct.
            float centroid = 0.0f;
            float rolloff = 0.0f;
            compute_spectral_features(mag, n_bins, (int)fh.sample_rate, (int)fft_size, rolloff_pct, &centroid, &rolloff);

            // MFCCs: DCT of log-mel filterbank energies.
            mfcc_compute(&bank, power, mfcc);

            int offset = 0;
            for (int i = 0; i < n_mfcc; i++) {
                sum[offset + i] += mfcc[i];
                sumsq[offset + i] += mfcc[i] * mfcc[i];
            }
            offset += n_mfcc;
            sum[offset] += rms;
            sumsq[offset] += rms * rms;
            offset++;
            sum[offset] += zcr;
            sumsq[offset] += zcr * zcr;
            offset++;
            sum[offset] += centroid;
            sumsq[offset] += centroid * centroid;
            offset++;
            sum[offset] += rolloff;
            sumsq[offset] += rolloff * rolloff;
        }

        // Write mean then std for each feature dimension.
        fprintf(out, "%s,%s", id, class_name);
        for (int i = 0; i < feat_dim; i++) {
            double mean = (num_frames > 0) ? sum[i] / (double)num_frames : 0.0;
            fprintf(out, ",%.6f", mean);
        }
        for (int i = 0; i < feat_dim; i++) {
            double mean = (num_frames > 0) ? sum[i] / (double)num_frames : 0.0;
            double var = (num_frames > 0) ? (sumsq[i] / (double)num_frames) - mean * mean : 0.0;
            if (var < 0.0) {
                var = 0.0;
            }
            fprintf(out, ",%.6f", sqrt(var));
        }
        fprintf(out, "\n");
        processed++;

        mfcc_free(&bank);
        free(frames);
        free(window);
        free(fft_in);
        free(real);
        free(imag);
        free(mag);
        free(power);
        free(mfcc);
        free(sum);
        free(sumsq);
        csv_free_row(&row);
    }

    fclose(meta);
    fclose(out);

    fprintf(stdout, "Summary: processed=%zu missing=%zu failed=%zu\n", processed, missing, failed);
    return 0;
}
