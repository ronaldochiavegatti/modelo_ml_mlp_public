#ifndef DSP_H
#define DSP_H

#include <stddef.h>

// Return the next power-of-two >= n (used for FFT sizing).
size_t next_pow2(size_t n);
// Fill an array with a Hamming window.
void hamming_window(float *win, size_t n);
// Compute FFT for a real-valued signal (n must be power-of-two).
int fft_real(const float *input, size_t n, float *real, float *imag);
// Compute magnitude spectrum for the positive-frequency bins.
void magnitude_spectrum(const float *real, const float *imag, size_t n, float *mag_out);

#endif
